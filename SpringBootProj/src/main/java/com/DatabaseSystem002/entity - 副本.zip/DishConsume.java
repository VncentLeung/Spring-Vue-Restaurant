package com.DatabaseSystem002.entity;


import java.sql.Timestamp;

public class DishConsume {

  private long uid;
  private String did;
  private String rid;
  private long dcounts;
  private java.sql.Timestamp delieverytime;
  private long uconsume;
  private java.sql.Timestamp utime;
  private String Delieverystatus;

  public long getUid() {
    return uid;
  }

  public void setUid(long uid) {
    this.uid = uid;
  }


  public String getDid() {
    return did;
  }

  public void setDid(String did) {
    this.did = did;
  }

  public String getDelieverystatus() {
    return Delieverystatus;
  }

  public void setDelieverystatus(String Delieverystatus) {
    this.Delieverystatus = Delieverystatus;
  }

  public String getRid() {
    return rid;
  }

  public void setRid(String rid) {
    this.rid = rid;
  }


  public long getDcounts() {
    return dcounts;
  }

  public void setDcounts(long dcounts) {
    this.dcounts = dcounts;
  }


  public java.sql.Timestamp getDelieverytime() {
    return delieverytime;
  }


  public void setDelieverytime(java.sql.Timestamp delieverytime) {
    this.delieverytime = delieverytime;
  }
  public void setDelieverytime(String delieverytime) {
    Timestamp ts = new Timestamp(System.currentTimeMillis());

    try {
      ts = Timestamp.valueOf(delieverytime);
      System.out.println(ts);
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.delieverytime = ts;
  }

  public long getUconsume() {
    return uconsume;
  }

  public void setUconsume(long uconsume) {
    this.uconsume = uconsume;
  }


  public java.sql.Timestamp getUtime() {
    return utime;
  }

  public void setUtime(java.sql.Timestamp utime) {
    this.utime = utime;
  }
  public void setUtime(String utime) {
    Timestamp ts = new Timestamp(System.currentTimeMillis());

    try {
      ts = Timestamp.valueOf(utime);
      System.out.println(ts);
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.utime = ts;
  }

}

