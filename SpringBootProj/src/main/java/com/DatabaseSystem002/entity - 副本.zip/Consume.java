package com.DatabaseSystem002.entity;
public class Consume {
  private String rid;
  private long uid;
  private String utype;
  private String uname;
  private long ucounts;
  private long uconsume;
  private java.sql.Timestamp utime;

  public String getRid() {
    return rid;
  }
  public void setRid(String rid) {
    this.rid = rid;
  }
  public long getUid() {
    return uid;
  }
  public void setUid(long uid) {
    this.uid = uid;
  }
  public String getUtype() {
    return utype;
  }
  public void setUtype(String utype) {
    this.utype = utype;
  }
  public String getUname() {
    return uname;
  }
  public void setUname(String uname) {
    this.uname = uname;
  }
  public long getUcounts() {
    return ucounts;
  }
  public void setUcounts(long ucounts) {
    this.ucounts = ucounts;
  }
  public long getUconsume() {
    return uconsume;
  }
  public void setUconsume(long uconsume) {
    this.uconsume = uconsume;
  }
  public java.sql.Timestamp getUtime() {
    return utime;
  }
  public void setUtime(java.sql.Timestamp utime) {
    this.utime = utime;
  }
}
