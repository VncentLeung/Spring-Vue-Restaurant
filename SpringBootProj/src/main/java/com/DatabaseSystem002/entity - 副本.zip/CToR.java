package com.DatabaseSystem002.entity;


import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;

public class CToR {

  private long cid;
  private String rid;

  private java.sql.Timestamp stime;
  private long ordertime;

  private java.sql.Timestamp etime;
  private long deposit;
  private long consume;


  public long getCid() {
    return cid;
  }

  public void setCid(long cid) {
    this.cid = cid;
  }


  public String getRid() {
    return rid;
  }

  public void setRid(String rid) {
    this.rid = rid;
  }


  public java.sql.Timestamp getStime() {
    return stime;
  }

  public void setStime(java.sql.Timestamp stime) {
    this.stime = stime;
  }

  public void setStime(String stime) {
    Timestamp ts = new Timestamp(System.currentTimeMillis());

    try {
      ts = Timestamp.valueOf(stime);
      System.out.println(ts);
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.stime = ts;
  }

  public long getOrdertime() {
    return ordertime;
  }

  public void setOrdertime(long ordertime) {
    this.ordertime = ordertime;
  }


  public java.sql.Timestamp getEtime() {
    return etime;
  }


  public void setEtime(String etime) {
    if(etime.length()==0)
    {
      this.etime=null;
    }
    Timestamp ts = new Timestamp(System.currentTimeMillis());
    try {
      ts = Timestamp.valueOf(etime);
      System.out.println(ts);
    } catch (Exception e) {
      e.printStackTrace();
    }
    this.etime = ts;
  }
  public void setEtime(java.sql.Timestamp etime) {
    this.etime = etime;
  }
  public long getDeposit() {
    return deposit;
  }


  public void setDeposit(String deposit) {
    if (deposit.length()==0)
      this.deposit=0;
    else{
      this.deposit=Long.valueOf(deposit);
    }
  }
  public void setDeposit(long deposit) {
    this.deposit = deposit;
  }

  public long getConsume() {
    return consume;
  }

  public void setConsume(String consume) {
    if (consume.length()==0)
      this.consume=0;
    else{
      this.consume=Long.valueOf(consume);
    }
  }
  public void setConsume(long consume) {
    this.consume = consume;
  }

}
