package com.DatabaseSystem002.entity;


public class Customer {
  private long cid;
  private String cname;
  private String csex;
  private String csid;
  private String ctel;

  public long getCid() {
    return cid;
  }
  public void setCid(long cid) {
    this.cid = cid;
  }
  public String getCname() {
    return cname;
  }
  public void setCname(String cname) {
    this.cname = cname;
  }
  public String getCsex() {
    return csex;
  }
  public void setCsex(String csex) {
    this.csex = csex;
  }
  public String getCsid() {
    return csid;
  }
  public void setCsid(String csid) {
    this.csid = csid;
  }
  public String getCtel() {
    return ctel;
  }
  public void setCtel(String ctel) {
    this.ctel = ctel;
  }

}
