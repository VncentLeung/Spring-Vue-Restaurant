package com.DatabaseSystem002.entity;


public class Room {
  private String rid;
  private String rtype;
  private long rprice;
  private String rstatus;


  public String getRid() {
    return rid;
  }

  public void setRid(String rid) {
    this.rid = rid;
  }


  public String getRtype() {
    return rtype;
  }

  public void setRtype(String rtype) {
    this.rtype = rtype;
  }


  public long getRprice() {
    return rprice;
  }

  public void setRprice(long rprice) {
    this.rprice = rprice;
  }


  public String getRstatus() {
    return rstatus;
  }

  public void setRstatus(String rstatus) {
    this.rstatus = rstatus;
  }

}
