package com.DatabaseSystem002.entity;


public class RoomConsume {

  private long uid;
  private String rid;
  private String rtype;
  private long ordertime;
  private long uconsume;
  private java.sql.Timestamp utime;


  public long getUid() {
    return uid;
  }

  public void setUid(long uid) {
    this.uid = uid;
  }


  public String getRid() {
    return rid;
  }

  public void setRid(String rid) {
    this.rid = rid;
  }


  public String getRtype() {
    return rtype;
  }

  public void setRtype(String rtype) {
    this.rtype = rtype;
  }


  public long getOrdertime() {
    return ordertime;
  }

  public void setOrdertime(long ordertime) {
    this.ordertime = ordertime;
  }


  public long getUconsume() {
    return uconsume;
  }

  public void setUconsume(long uconsume) {
    this.uconsume = uconsume;
  }


  public java.sql.Timestamp getUtime() {
    return utime;
  }

  public void setUtime(java.sql.Timestamp utime) {
    this.utime = utime;
  }

}
