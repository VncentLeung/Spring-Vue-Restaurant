package com.DatabaseSystem002.entity;
public class CToR {

  private long cid;
  private long kid;
  private java.sql.Timestamp crtime;


  public long getCid() {
    return cid;
  }

  public void setCid(long cid) {
    this.cid = cid;
  }


  public long getKid() {
    return kid;
  }

  public void setKid(long kid) {
    this.kid = kid;
  }


  public java.sql.Timestamp getCrtime() {
    return crtime;
  }

  public void setCrtime(java.sql.Timestamp crtime) {
    this.crtime = crtime;
  }

}
