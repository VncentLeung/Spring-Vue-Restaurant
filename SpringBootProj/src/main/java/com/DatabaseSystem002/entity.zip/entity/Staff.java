package com.DatabaseSystem002.entity;


public class Staff {

  private String ssid;
  private String sname;
  private String sid;
  private String stype;


  public String getSsid() {
    return ssid;
  }

  public void setSsid(String ssid) {
    this.ssid = ssid;
  }


  public String getSname() {
    return sname;
  }

  public void setSname(String sname) {
    this.sname = sname;
  }


  public String getSid() {
    return sid;
  }

  public void setSid(String sid) {
    this.sid = sid;
  }


  public String getStype() {
    return stype;
  }

  public void setStype(String stype) {
    this.stype = stype;
  }

}
