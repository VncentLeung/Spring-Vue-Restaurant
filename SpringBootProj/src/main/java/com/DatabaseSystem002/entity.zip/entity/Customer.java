package com.DatabaseSystem002.entity;


public class Customer {

  private long cid;
  private String ctel;


  public long getCid() {
    return cid;
  }

  public void setCid(long cid) {
    this.cid = cid;
  }


  public String getCtel() {
    return ctel;
  }

  public void setCtel(String ctel) {
    this.ctel = ctel;
  }

}
