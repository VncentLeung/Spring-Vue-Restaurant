package com.DatabaseSystem002.entity;


public class Dish {

  private String did;
  private String dtype;
  private String dkind;
  private String dname;
  private String dcount;
  private long dprice;
  private String dstatus;
  private String dimg;


  public String getDid() {
    return did;
  }

  public void setDid(String did) {
    this.did = did;
  }


  public String getDtype() {
    return dtype;
  }

  public void setDtype(String dtype) {
    this.dtype = dtype;
  }


  public String getDkind() {
    return dkind;
  }

  public void setDkind(String dkind) {
    this.dkind = dkind;
  }


  public String getDname() {
    return dname;
  }

  public void setDname(String dname) {
    this.dname = dname;
  }


  public String getDcount() {
    return dcount;
  }

  public void setDcount(String dcount) {
    this.dcount = dcount;
  }


  public long getDprice() {
    return dprice;
  }

  public void setDprice(long dprice) {
    this.dprice = dprice;
  }


  public String getDstatus() {
    return dstatus;
  }

  public void setDstatus(String dstatus) {
    this.dstatus = dstatus;
  }


  public String getDimg() {
    return dimg;
  }

  public void setDimg(String dimg) {
    this.dimg = dimg;
  }

}
