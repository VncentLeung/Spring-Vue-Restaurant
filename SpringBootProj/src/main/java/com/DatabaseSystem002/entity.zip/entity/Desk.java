package com.DatabaseSystem002.entity;


public class Desk {

  private long kid;
  private String ktype;
  private long knum;
  private String kstatus;


  public long getKid() {
    return kid;
  }

  public void setKid(long kid) {
    this.kid = kid;
  }


  public String getKtype() {
    return ktype;
  }

  public void setKtype(String ktype) {
    this.ktype = ktype;
  }


  public long getKnum() {
    return knum;
  }

  public void setKnum(long knum) {
    this.knum = knum;
  }


  public String getKstatus() {
    return kstatus;
  }

  public void setKstatus(String kstatus) {
    this.kstatus = kstatus;
  }

}
