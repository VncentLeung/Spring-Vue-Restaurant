package com.DatabaseSystem002.entity;



public class Dishordertop5 {

  private double sum;
  private String dname;


  public double getSum() {
    return sum;
  }

  public void setSum(double sum) {
    this.sum = sum;
  }


  public String getDname() {
    return dname;
  }

  public void setDname(String dname) {
    this.dname = dname;
  }

}
